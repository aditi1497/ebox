import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Collections/Generics, Lists / session2
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList <Integer> runs = new ArrayList<Integer>();
		
		int players = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < players; i++){
			runs.add(Integer.parseInt(sc.nextLine()));
		}
		
		int sum = 0;
		boolean evenFlag = true;
		
		for(int i :runs){
			if(evenFlag == false){
				evenFlag = true;
				sum += i;
			}
			else
				evenFlag = false;
		}
		
		System.out.println(sum);
	}

}
