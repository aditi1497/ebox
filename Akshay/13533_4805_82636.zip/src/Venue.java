
public class Venue {
	
	private String name;
	private String city;
	
	
	//Default (String, String) constructor
	public Venue(String name, String city){
		this.name = name;
		this.city = city;
	}
	
	//Default empty constructor
	public Venue(){
		
	}
	
	//Setters
	public void setName(String venueName){
		name = venueName;
	}
	
	public void setCity(String cityName){
		city = cityName;
	}

	
	//Getters
	public String getName(){
		return name;
	}
	
	public String getCity(){
		return city;
	}
	
	//Display saved details
	public void display(){
		System.out.println("Venue Name : " + name);
		System.out.println("City Name : " + city);
	}
}
