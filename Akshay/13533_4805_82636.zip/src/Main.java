import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* Classes and objects I/Sess 1
		int venues;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of venues");
		venues = sc.nextInt();
		sc.nextLine();
		
		Venue[] ven = new Venue[venues];
		
		String venueDetails = new String();
		
		
		for(int i = 0; i < venues; i++){
			
			System.out.println("Enter the details of venue " + (i+1));
			venueDetails = sc.nextLine();
			String [] details = venueDetails.split(",");
			
			//System.out.println(details[0]+" "+details[1]);
			ven[i] = new Venue(details[0], details[1]);
			}

		//Displaying details
		System.out.println("Venue Details");
		
		for(int i = 0; i < venues; i++){
			ven[i].display();
		}
		*/
		
/*		Scanner sc = new Scanner(System.in);
		
		int innings;
		System.out.println("Enter the number of innings");
		innings = Integer.parseInt(sc.nextLine());
		
		Innings []inn = new Innings[innings];
		
		for(int i = 0; i < innings; i ++){
			
			System.out.println("Enter the values for Innings " + (i +1));
			String bt;
			Long run;
			System.out.println("Enter the BattingTeam");
			bt = sc.nextLine();
			System.out.println("Enter the runs scored");
			run = Long.parseLong(sc.nextLine());
			
			inn[i] = new Innings(bt, run);
			
		}
		
		System.out.println("Innings Details");
		for(int i = 0; i < innings; i ++){
			System.out.println("Innings " + (i+1));
			System.out.println(inn[i].toString());
		}*/
		
		Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player 1 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P1 = new Player(name, country, skill);
		System.out.println(P1.toString());
		
		System.out.println("Enter player 2 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P2 = new Player(name, country, skill);
		System.out.println(P2.toString());
		
		if(P1.equals(P2))
			System.out.println("Both the player details are the same.");
		else
			System.out.println("Both the player details are not the same.");

		
	}
	
	public static boolean equals(Player P1, Player P2){
		return P1.equals(P2);
	}

}
