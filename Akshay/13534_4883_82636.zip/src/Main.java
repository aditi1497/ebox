import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int players = 0;
		String name;
		String country;
		String skill;
		
		System.out.println("Enter the number of players");
		players = Integer.parseInt(sc.nextLine());
		
		Player playerList[] = new Player[players];
		
		for(int i = 0; i < players; i ++){
			
			System.out.println("Enter player " + (i+1) +" details");
			System.out.println("Enter the player name");
			name = sc.nextLine();
			System.out.println("Enter the country name");
			country = sc.nextLine();
			System.out.println("Enter the skill");
			skill = sc.nextLine();
			
			playerList[i] = new Player(name, country, skill);
		}
		
		System.out.println("Player Details");
		for(Player p :playerList)
			System.out.println(p);
		
		sc.close();
		
		
	}

}
