import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int Date = Integer.parseInt(sc.nextLine());
		
		if(Date%4 == 0 && Date%100 != 0)
			System.out.println("Yes");
		else if(Date%100 == 0 && Date % 400 == 0)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		sc.close();
	}

}
