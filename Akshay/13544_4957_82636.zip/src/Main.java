import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//Classes and object Iv/Sess 2/Match Class, Venue Class, city
				Scanner sc = new Scanner(System.in);
				
				//Input city details
				int cityCount;
				System.out.println("Enter the city count");
				cityCount = Integer.parseInt(sc.nextLine());
				City [] cityList = new City[cityCount];
				//Creating array of cities
				for(int i = 0; i < cityCount; i++){
					String cityTemp = new String();
					System.out.println("Enter city " + (i+1) + " details");
					cityTemp = sc.nextLine();
					cityList[i] = new City(cityTemp);
				}
				
				//Input venue details
				int venueCount;
				System.out.println("Enter the venue count");
				venueCount = Integer.parseInt(sc.nextLine());
				Venue [] venueList = new Venue[venueCount];
				//Venue manipulation object
				VenueBO vbo = new VenueBO();
				//Creating array of venues
				for(int i = 0; i < venueCount; i++){
					String venueTemp = new String();
					System.out.println("Enter venue " + (i+1) + " details");
					venueTemp = sc.nextLine();
					venueList[i] = new Venue();
					venueList[i] = vbo.createVenue(venueTemp, cityList);
				}
				
				//Input match details
				int matchCount;
				System.out.println("Enter the match count");
				matchCount = Integer.parseInt(sc.nextLine());
				Match [] matchList = new Match[matchCount];
				//Match manipulation object
				MatchBO mbo = new MatchBO();
				//Creating array of matches
				for(int i = 0; i < matchCount; i++){
					String matchTemp = new String();
					System.out.println("Enter match " + (i+1) + " details");
					matchTemp = sc.nextLine();
					matchList[i] = new Match();
					matchList[i] = mbo.createMatch(matchTemp, venueList);
				}
				
				======Menu=======
				System.out.println("Menu :");
				System.out.println("1)Find Venue");
				System.out.println("2)Find All Matches In A Specific Venue");
				System.out.println("Type 1 or 2");
				
				while(true){
					int ch;
					System.out.println("Enter your choice");
					ch = Integer.parseInt(sc.nextLine());
					
					if(ch == 1){
						String matchDate = new String();
						System.out.println("Enter Match Date");
						matchDate = sc.nextLine();
						mbo.findVenue(matchDate, matchList);
					}
					else if(ch == 2){
						String venueName = new String();
						System.out.println("Enter Venue Name");
						venueName = sc.nextLine();
						mbo.findAllMatchesInGivenVenue(venueName, matchList);
					}
					
					String cont = new String();
					System.out.println("Do you want to continue? Type Yes or No");
					cont = sc.nextLine();
					//Continue only if input is yes
					if(cont.equals("Yes"))
						continue;
					//Break from iteration structure in any other case
					else
						break;
					
				}*/
		//Strings /Sess1/EqualsIgnoreCase
		
		Scanner sc = new Scanner(System.in);
		
		String venue1 = new String();
		String venue2 = new String();
		
		System.out.println("Enter venue1");
		venue1 = sc.nextLine();
		System.out.println("Enter venue2");
		venue2 = sc.nextLine();
		
		
		if(venue1.equalsIgnoreCase(venue2))
			System.out.println("Both the venues are same.");
		else
			System.out.println("Both the venues are different.");
	}

}
