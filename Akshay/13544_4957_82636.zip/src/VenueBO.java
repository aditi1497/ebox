
public class VenueBO {

	public Venue createVenue(String data, City[] cityList){
		
		String [] venueDetails = data.split(",");
		Venue v = new Venue();
		v.setName(venueDetails[0]);
		
		for(City c: cityList){
			if(c.getName().equals(venueDetails[1]))
				v.setCity(c);
		}
		
		return v;
	}
	
	
}
