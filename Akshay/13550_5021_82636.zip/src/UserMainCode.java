import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserMainCode {
	
	
	
	public static void displayDate(String date) throws ParseException{
		
		String[] dateArray = date.split(" ");
		int dd, mm, yyyy;
		
		
		if(dateArray[0] != null){

			
			SimpleDateFormat given = new SimpleDateFormat("MMMM dd, yyyy");
			Date dt = new Date();
			dt = given.parse(date);
			
			SimpleDateFormat result = new SimpleDateFormat("yyyy-MM-dd");
			
			String returnDate = new String();
			returnDate = result.format(dt);
			System.out.println(returnDate);

		}
		
	}
	
	
	
	public static void displayDateTime(String date) throws ParseException{
		
		SimpleDateFormat given = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dt = new Date();
		dt = given.parse(date);
		
		String destination = new String();
		SimpleDateFormat result = new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");
		destination = result.format(dt);
		
		System.out.println(destination);
	}
	

}



/*

dd = Integer.parseInt(dateArray[1].substring(0, dateArray[1].length() - 1));
yyyy = Integer.parseInt(dateArray[2].substring(0, dateArray[1].length()));
Date date1 = new SimpleDateFormat("MMMM", Locale.ENGLISH).parse(dateArray[0]);


*/