import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String date = sc.nextLine();
		sc.close();
		
		System.out.println("Enter String in this format(yyyy-MM-DD HH:mm:ss)");
		UserMainCode.displayDateTime(date);
		
	}

}
