import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.w3c.dom.UserDataHandler;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		//Collections 1/List1
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> l = new ArrayList<Integer>();
		
		int length;
		length = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < length; i++){
			
			int i1 = Integer.parseInt(sc.nextLine());
			l.add(i1);
		}
		
		float sum = 0;
		for(Object o:l)
			sum += (int)o;
		
		System.out.println((int)sum);
		System.out.println(String.format("%.1f", sum/length));
		
		sc.close();
		*/
		
		
		
		//Collections 1/List2
				Scanner sc = new Scanner(System.in);
				
				ArrayList<Integer> l = new ArrayList<Integer>();
				
				int length;
				length = Integer.parseInt(sc.nextLine());
				
				for(int i = 0; i < length; i++){
					
					int i1 = Integer.parseInt(sc.nextLine());
					l.add(i1);
				}
				
				Collections.sort(l);
				
				for(int i:l){
					System.out.println(i);
				}

				
				sc.close();
		
	}

}
