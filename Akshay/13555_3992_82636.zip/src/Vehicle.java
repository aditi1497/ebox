
public class Vehicle {
	
	protected String make;
	protected String vehicleNumber;
	protected String fuelType;
	protected int fuelCapacity;
	protected int cc;
	
	//Getters and Setters
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public int getFuelCapacity() {
		return fuelCapacity;
	}
	public void setFuelCapacity(int i) {
		this.fuelCapacity = i;
	}
	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	
	//Constructor (String X4, int)
	public Vehicle(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc) {
		super();
		this.make = make;
		this.vehicleNumber = vehicleNumber;
		this.fuelType = fuelType;
		this.fuelCapacity = fuelCapacity;
		this.cc = cc;
	}
	//Empty Constructor
	public Vehicle() {

	}
	
	//Display model/make (Definition)
	void displayMake(){
		System.out.println("***" + make + "***");
	}
	
	//Display basic Info
	public void dislayBasicInfo(){
		
			System.out.println("---Basic Information---");
			System.out.println("Vehicle Number:" +vehicleNumber);
			System.out.println("Fuel Capacity:" + fuelCapacity);
			System.out.println("Fuel Type:" +fuelType);
			System.out.println("CC:" + cc);
		
	}
	
	//Display detailed info about vehicle (definition)
	void displayDetailInfo(){};
		
	
}
