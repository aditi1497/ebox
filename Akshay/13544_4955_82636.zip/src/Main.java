import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Strings/Session1/CharAt
		
		Scanner sc = new Scanner(System.in);
		
		char character1 = 0;
		String team1 = new String();
		String team2 = new String();
		System.out.println("Enter team1");
		team1 = sc.nextLine();
		System.out.println("Enter team2");
		team2 = sc.nextLine();
		System.out.println("Enter third character");
		character1 = sc.nextLine().charAt(0);
		
		if(team1.charAt(2) == character1)
			System.out.println("Winner Team : " + team1);
		else if(team2.charAt(2) == character1)
			System.out.println("Winner Team : " + team2);
	}

}
