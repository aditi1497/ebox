import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Classes and Objects III/Sess2
		Scanner sc = new Scanner(System.in);
		
		int wickets;
		System.out.println("Enter the number of wickets");
		wickets = Integer.parseInt(sc.nextLine());
		
		//Array of wickets
		Wicket [] wicketList = new Wicket[wickets];
		
		
		
		for(int i = 0; i < wickets; i++){
			
			String str = new String();
			System.out.println("Enter the details of wicket " + (i+1));
			str = sc.nextLine();
			
			//For storing 5 detail fields of each wicket
			String[] wicketDetails = str.split(",");
			
			wicketList[i] = new Wicket(Long.parseLong(wicketDetails[0]), Long.parseLong(wicketDetails[1]), wicketDetails[2], wicketDetails[3], wicketDetails[4]);
		}
		
		WicketBO wbo = new WicketBO();
		wbo.displayAllWicketDetails(wicketList);
		
		String wicketType = new String();
		System.out.println("Enter the wicket type to be searched");
		wicketType = sc.nextLine();
		wbo.displaySpecificWicketDetails(wicketList, wicketType);
	}

}
