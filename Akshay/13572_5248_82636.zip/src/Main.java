import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String player;
		String team;
		
		System.out.println("Enter the player name");
		player = sc.nextLine();
		System.out.println("Enter the team name");
		team = sc.nextLine();
		UserMainCode.display(player, team);
		sc.close();
		
	}

}
