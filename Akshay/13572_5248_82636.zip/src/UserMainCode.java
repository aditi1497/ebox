
public class UserMainCode {

	public static void display(String player, String team){
		StringBuffer details = new StringBuffer();
		details.append(player);
		details.append("#");
		details.append(team);
		System.out.println(details);
	}
}
