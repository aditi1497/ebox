import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		/*
		//String Sess2/ Validation IV
		Scanner sc = new Scanner(System.in);
		
		String str = new String();
		str = sc.nextLine();
		
		if(UserMainCode.validateCity(str) == true)
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		sc.close();
		*/
		
/*		
		//String Sess2/Validation VII
		
		Scanner sc = new Scanner(System.in);
		
		String Player = new String();
		Player = sc.nextLine();
		
		if(UserMainCode.validatePlayer(Player))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		
		sc.close();
		*/
		
		
		//Strings sess2/ Clara monthly budget
		Scanner sc = new Scanner(System.in);
		
		String budget = new String();
		budget = sc.nextLine();

		System.out.println(ClaraFUp.PossibleThreeDigitSubstrings(budget));
		
		sc.close();
	}

}
