
public class UserMainCode {
	
	/*
	//Strings sess2 / ValidationIV
	public static boolean validateCity(String city){
		boolean validity = true;
		String ast = new String();
		
		for(int i = 4; i < city.length(); i++)
			ast = ast + "*";

		if(Character.isLetter(city.charAt(0)) && Character.isLetter(city.charAt(1)) && Character.isLetter(city.charAt(city.length() - 2)) && Character.isLetter(city.charAt(city.length() - 1))){
			if(ast.compareTo(city.substring(2, city.length() - 2)) == 0)
					validity = true;
			else
				validity = false;
			
			for(int i = 2; i < city.length() - 2; i++){
				if(city.charAt(i) == '*')
					continue;
				else
					validity = false;
					
			}
		else
			validity = false;
			
		return validity;
		
	}
		*/
		
	
	//Strings sess2/ Validation VII
	public static boolean validatePlayer(String Player){
		
		boolean validity = true;
		int length = Player.length();
		
		for(int i = 0; i < length; i++){
			
			//'a' or 'A' at even occurence
			if((Player.charAt(i) == 'a' || Player.charAt(i) == 'A') && (((i+1)%2) == 0)){
				validity = false;
				break;
			}
		}
		
		return validity;
		
	}
}
