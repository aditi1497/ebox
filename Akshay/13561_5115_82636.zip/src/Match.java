import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Match {
	
	
	//Display mathc date
	void displayMatchDetails(String matchDate) throws ParseException{
		
		SimpleDateFormat input = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("MM-dd-yyyy");
		
		Date d1 = input.parse(matchDate);
	
		
		System.out.println("Match Date : " + output.format(d1));
	}
	
	//Display venue details
	void displayMatchDetails(String[] venue){
		
		System.out.println("Match Venue :");
		System.out.println("Stadium : " + venue[0]);
		System.out.println("City : " + venue[1] );
	}
	
	//Display match outcome
	void displayMatchDetails(String winnerTeam, long runs){
		
		System.out.println("Match Outcome :");
		System.out.println(winnerTeam + " won by " + runs + " runs");
	}
}
