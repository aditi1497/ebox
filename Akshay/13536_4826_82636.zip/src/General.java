
public class General extends Compartment{

	public void notice(){
		System.out.println("General compartment");
	}
}
