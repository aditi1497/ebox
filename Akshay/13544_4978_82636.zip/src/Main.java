import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//Strings/Session1/CharAt
		
		Scanner sc = new Scanner(System.in);
		
		char character1 = 0;
		String team1 = new String();
		String team2 = new String();
		System.out.println("Enter team1");
		team1 = sc.nextLine();
		System.out.println("Enter team2");
		team2 = sc.nextLine();
		System.out.println("Enter third character");
		character1 = sc.nextLine().charAt(0);
		
		if(team1.charAt(2) == character1)
			System.out.println("Winner Team : " + team1);
		else if(team2.charAt(2) == character1)
			System.out.println("Winner Team : " + team2);
			*/
		
		
		/*
		//Strings /Sess1/EqualsIgnoreCase
		
		Scanner sc = new Scanner(System.in);
		
		String venue1 = new String();
		String venue2 = new String();
		
		System.out.println("Enter venue1");
		venue1 = sc.nextLine();
		System.out.println("Enter venue2");
		venue2 = sc.nextLine();
		
		
		if(venue1.equalsIgnoreCase(venue2))
			System.out.println("Both the venues are the same.");
		else
			System.out.println("Both the venues are different.");
			
			*/
		
		/*
		//Strings / Session1/ IndexOf, LastIndexOf
		
		Scanner sc = new Scanner(System.in);
		
		int numberOfPlayers;
		System.out.println("Enter the number of players");
		numberOfPlayers = Integer.parseInt(sc.nextLine());
		
		String [] playerList = new String[numberOfPlayers];
		
		for(int i = 0; i < numberOfPlayers; i++){
			playerList[i] = sc.nextLine();
		}
		
		System.out.println("Player of the Match:");
		for(String str: playerList){
			if(str.indexOf('a') == str.lastIndexOf('a'))
				System.out.println(str);
				
			}
			
		*/
		
		
		/*
		//Strings/Sess1/SubSequence
		
		Scanner sc = new Scanner(System.in);
		
		String teamName = new String();
		
		System.out.println("Enter team name");
		teamName = sc.nextLine();
		
		int stInd, endInd;
		
		System.out.println("Enter starting index of the sequence");
		stInd = Integer.parseInt(sc.nextLine());
		System.out.println("Enter ending index of the sequence");
		endInd = Integer.parseInt(sc.nextLine());
		
		System.out.println(teamName.substring(stInd, endInd));
		*/
		
		/*
		//Strings/sess1/Substring
		Scanner sc = new Scanner(System.in);
		
		String player = new String();
		int stInd;
		
		System.out.println("Enter Player name");
		player = sc.nextLine();
		
		System.out.println("Enter starting index");
		stInd = Integer.parseInt(sc.nextLine());
		
		System.out.println("Short name of " + player + ": " + player.substring(stInd));
	*/
		
		/*
		//Strings/sess1/startswith,endswith
		Scanner sc = new Scanner(System.in);
		
		int players;
		
		System.out.println("Enter the number of players");
		players = Integer.parseInt(sc.nextLine());
		
		String[] playerList = new String[players];
		
		System.out.println("Enter the player name");
		for(int i = 0; i < players; i++){
			playerList[i] = new String();
			playerList[i] = sc.nextLine();
		}
		
		System.out.println("Player name starting with 'M' or Ending with 'a'");
		for(String str: playerList){
			if(str.startsWith("M") || str.endsWith("a"))
				System.out.println(str);
		}
		*/
		
		
		/*		
		//Strings/Sess1/RegionMatches
		
		Scanner sc = new Scanner(System.in);
		
		String [] players = new String[2];
		
		System.out.println("Enter player names");
		players[0] =  sc.nextLine();
		players[1] =  sc.nextLine();
		
		if(players[0].regionMatches(0, players[1], 0, 7) && players[0].substring(0,7).equals("Michael"))
			System.out.println("Both the players names starts with Michael");
		else
			System.out.println("Both the players names does not starts with Michael");
	
		sc.close();
		*/
		
		/*
		//Strings/sess1/Replace
		
		Scanner sc = new Scanner(System.in);
		String teamDetails = new String();
		
		System.out.println("Enter team details");
		teamDetails = sc.nextLine();
		
		
		
		System.out.println("After replacement\n" + teamDetails.replaceAll("Captain", "Skipper"));
		sc.close();
		*/
		
		
		
		//Strings/sess1/Contains
		Scanner sc = new Scanner(System.in);
		
		int players;
		
		System.out.println("Enter number of players");
		players = Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter player names");
		
		String [] playerList = new String[players];
		
		for(int i = 0; i < players; i++)
			playerList[i] = sc.nextLine();
		
		for(String str: playerList){
			if(str.contains("Sharma"))
				System.out.println(str);
		}
		
		
		sc.close();
		
	}

}
