import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int venues;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of venues");
		venues = sc.nextInt();
		sc.nextLine();
		
		Venue[] ven = new Venue[venues];
		
		String venueDetails = new String();
		
		
		for(int i = 0; i < venues; i++){
			
			System.out.println("Enter the details of venue " + (i+1));
			venueDetails = sc.nextLine();
			String [] details = venueDetails.split(",");
			
			//System.out.println(details[0]+" "+details[1]);
			ven[i] = new Venue(details[0], details[1]);
			}

		//Displaying details
		System.out.println("Venue Details");
		
		for(int i = 0; i < venues; i++){
			ven[i].display();
		}
		
		
	}

}
