
public class Player {

	protected String name;
	protected String country;
	
	//Getters and Setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	//Constructor (String, String)
	public Player(String name, String country) {
		super();
		this.name = name;
		this.country = country;
	}
	
	//Display Player Details
	public void displayDetails(){
		
	}
	
	
}
