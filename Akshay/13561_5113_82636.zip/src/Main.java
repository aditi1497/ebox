import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		
		/*
		//Method Overriding/Overloading sess 1/ Match Details
		Match m = new Match();
		
		//Menu
		System.out.println("Menu");
		System.out.println("1.Match Date");
		System.out.println("2.Match Venue");
		System.out.println("3.Match Outcome");
		
		int choice;
		
		Scanner sc = new Scanner(System.in);
		
		choice = Integer.parseInt(sc.nextLine());
		
		if(choice == 1){
			String matchDate = new String();
			System.out.println("Enter the date of the match");
			matchDate = sc.nextLine();
			SimpleDateFormat input = new SimpleDateFormat("dd/MM/yyyy");
			m.displayMatchDetails((matchDate));
		}
		else if(choice == 2){
			String venue = new String();
			System.out.println("Enter venue of the match");
			venue = sc.nextLine();
			String []venueList = venue.split(",");
			m.displayMatchDetails(venueList);
		}
		else if(choice == 3){
			String winnerTeam = new String();
			long runs;
			System.out.println("Enter the winner team of the match");
			winnerTeam = sc.nextLine();
			System.out.println("Enter the number of runs");
			runs = Long.parseLong(sc.nextLine());
			m.displayMatchDetails(winnerTeam, runs);
		}
		
		sc.close();
		*/
		
		
		//Method Overriding/Overloading sess 1/ Player-Internaional Player
		Player p;
		
		//Player parameters
		String name;
		String country;
		String capNumber;
		long noOfTestAppearance;
		long noOfODIAppearance;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter player name ");
		name = sc.nextLine();
		System.out.println("Enter player country");
		country = sc.nextLine();
		System.out.println("Enter the Cap number");
		capNumber = sc.nextLine();
		System.out.println("Enter the number of test appearnace");
		noOfTestAppearance = Long.parseLong(sc.nextLine());
		System.out.println("Enter the number of ODI appearnace");
		noOfODIAppearance = Long.parseLong(sc.nextLine());
		
		p = new InternationalPlayer(name, country, capNumber, noOfTestAppearance, noOfODIAppearance);
		
		//Display details
		p.displayDetails();
	}

}
