import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//String_buff_sess2/Display match summaries 1
		Scanner sc = new Scanner(System.in);
		
		String summary = sc.nextLine();
		Jumble.displaySummary(summary);
		
		sc.close();
	}

}
