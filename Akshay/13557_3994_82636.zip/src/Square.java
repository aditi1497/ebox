
public class Square extends Shape{

	private Integer side;
	
	public Square(String name, int side) {
		// TODO Auto-generated constructor stub
		super(name);
		this.side = side;
		
	}
	
	//Getters and Setters
	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	@Override
	public float calculateArea() {
		// TODO Auto-generated method stub
		return side*side;
	}
	
	
	
}
