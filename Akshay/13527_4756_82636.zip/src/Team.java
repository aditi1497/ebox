
public class Team {
	
	/*
	//Code Challenge/ Classes and Objects 1
	private String name;
	private String coach;
	private String home;
	private String captain;
	private String players;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCoach() {
		return coach;
	}
	public void setCoach(String coach) {
		this.coach = coach;
	}
	public String getHome() {
		return home;
	}
	public void setHome(String home) {
		this.home = home;
	}
	public String getCaptain() {
		return captain;
	}
	public void setCaptain(String captain) {
		this.captain = captain;
	}
	public String getPlayers() {
		return players;
	}
	public void setPlayers(String players) {
		this.players = players;
	}
	
	*/
	
	
	//Classes and object 1b/ Sess 2
	private String name;
	private String coach;
	private String location;
	private String players;
	private String captain;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCoach() {
		return coach;
	}
	public void setCoach(String coach) {
		this.coach = coach;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPlayers() {
		return players;
	}
	public void setPlayers(String players) {
		this.players = players;
	}
	public String getCaptain() {
		return captain;
	}
	public void setCaptain(String captain) {
		this.captain = captain;
	}
	
	public void displayTeamDetails(){
		
		System.out.println("Team Details");
		System.out.println("Team : " + name);
		System.out.println("Coach : " + coach);
		System.out.println("Location : " + location);
		System.out.println("Players : " + players);
		System.out.println("Captain : " + captain);

	}
	

}
