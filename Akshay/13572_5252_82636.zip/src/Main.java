import java.util.Scanner;

import javax.jws.soap.SOAPBinding.Use;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		//String buff_sess1/Player-team
		Scanner sc = new Scanner(System.in);
		
		String player;
		String team;
		
		System.out.println("Enter the player name");
		player = sc.nextLine();
		System.out.println("Enter the team name");
		team = sc.nextLine();
		UserMainCode.display(player, team);
		sc.close();
		*/
		
		
		//String buff_sess1/ String Builder
		
		Scanner sc = new Scanner(System.in);
		
		String fname;
		String lname;
		
		//Input
		fname = sc.nextLine();
		lname = sc.nextLine();
		
		UserMainCode.display(fname, lname);
		
		sc.close();
		
	}

}
