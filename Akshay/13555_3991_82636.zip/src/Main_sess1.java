import java.util.Scanner;

public class Main_sess1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner sc = new Scanner(System.in);
		
		//Menu
		do{
			int choice;
			
			System.out.println("1. Rectangle");
			System.out.println("2. Square");
			System.out.println("3. Circle");
			
			System.out.println("Area Calculator --- Choose your shape");
			choice = Integer.parseInt(sc.nextLine());
			if(choice == 1){
				int length, breadth;
				System.out.println("Enter length and breadth:");
				length = Integer.parseInt(sc.nextLine());
				breadth = Integer.parseInt(sc.nextLine());
				Rectangle rec = new Rectangle(length, breadth);
				System.out.println("Area of Rectangle is:" + String.format("%.2f",rec.calculateArea()));
			}
			else if(choice == 2){
				int side;
				System.out.println("Enter side:");
				side = Integer.parseInt(sc.nextLine());
				Square sq = new Square(side);
				System.out.println("Area of Square is:" + String.format("%.2f", sq.calculateArea()));
			}
			else if(choice == 3){
				int radius;
				System.out.println("Enter Radius:");
				radius = Integer.parseInt(sc.nextLine());		
				Circle c = new Circle(radius);
				System.out.println("Area of Circle is:" + String.format("%.2f", c.calculateArea()));
			}
			
			
		}while(false);
	}

}
