
public class Square extends Shape{
	
	private int side;

	//Getters and Setters
	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}
	
	//Constructor (int)
	public Square(int side) {
		this.shapeName = "Square";
		this.side = side;
	}
	
	
	//Returning side multiplied with side as area
	public Double calculateArea(){
		
		Double d = (double) side*side; 
		//String str = String.format("%.2f", d);
		
		return d;
	}
	

}
