import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		//Fundamentals Session1/Dhoni Marriage 
		Scanner sc = new Scanner(System.in);
		int Date = Integer.parseInt(sc.nextLine());
		
		if(Date%4 == 0 && Date%100 != 0)
			System.out.println("Yes");
		else if(Date%100 == 0 && Date % 400 == 0)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		sc.close();
		*/
		
		
		/*		
		//Fundamentals Session 1/Dhoni First meet
		Scanner sc = new Scanner(System.in);
		
		int seat = Integer.parseInt(sc.nextLine());
		
		if(seat%6 == 5 || seat%6 == 2)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		sc.close();
		*/
		
		
		/*
		//Fundamentals Session 1/Dhoni's Day Out
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> posterCosts = new ArrayList<Integer>();
		
		for(int i = 0; i < 5; i++)
			posterCosts.add(Integer.parseInt(sc.nextLine()));
		
		int durgaPoster = posterCosts.get(0);
		int money = posterCosts.get(4);
		
		posterCosts.remove(4);
		posterCosts.remove(0);

		Collections.sort(posterCosts);
		
		int moneyLeft = money-durgaPoster;
		
		if(moneyLeft <= 0)
			System.out.println("0");
		else if(moneyLeft-(posterCosts.get(0) + posterCosts.get(1) + posterCosts.get(2)) >= 0)
			System.out.println("3");
		else if(moneyLeft-(posterCosts.get(0) + posterCosts.get(1)) >= 0)
			System.out.println("2");
		else if(moneyLeft-(posterCosts.get(0) + posterCosts.get(2)) >= 0)
			System.out.println("2");
		else if(moneyLeft-(posterCosts.get(2) + posterCosts.get(1)) >= 0)
			System.out.println("2");
		else if(moneyLeft - posterCosts.get(2) >= 0)
			System.out.println("1");
		else if(moneyLeft - posterCosts.get(1) >= 0)
			System.out.println("1");
		else if(moneyLeft - posterCosts.get(0) >= 0)
			System.out.println("1");
		else
			System.out.println("0");
		sc.close();
		*/
		
		/*
		
		//Fundamentals Session1/Player selection for cricket team
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> scoreList = new ArrayList<Integer>();
		
		int cent = 0, hcent = 0;
		
		scoreList.add(Integer.parseInt(sc.nextLine()));
		scoreList.add(Integer.parseInt(sc.nextLine()));
		scoreList.add(Integer.parseInt(sc.nextLine()));
		
		for(int i :scoreList){
			if(i>=100)
				cent++;
			if(i>=50)
				hcent++;
		}
		
		
		//System.out.println(cent);
		if(cent>=2 || (hcent == 3))
			System.out.println("Selected");
		else if(cent >= 1 || hcent >= 2)
			System.out.println("Waitlisted");
		else
			System.out.println("Rejected");
		
		sc.close();
		*/
		
		
		
		//Fundamentals Session1/Valentine's gift
		Scanner sc = new Scanner(System.in);
		
		int g1 = Integer.parseInt(sc.nextLine());
		int g2 = Integer.parseInt(sc.nextLine());
		int g3 = Integer.parseInt(sc.nextLine());
		int money = Integer.parseInt(sc.nextLine());
		String credit = sc.nextLine();
		
		if(credit.equals("true") || money>=(g1+g2+g3))
			System.out.println("3");
		else if(money >= (g1+g2))
			System.out.println("2");
		else if(money >= (g1+g3))
			System.out.println("2");
		else if(money >= (g3+g2))
			System.out.println("2");
		else if(money >= (g1))
			System.out.println("1");
		else if(money >= (g2))
			System.out.println("1");
		else if(money >= (g3))
			System.out.println("1");
		else
			System.out.println("0");
		sc.close();
		
		
	}

}
