import java.util.Scanner;

import javax.jws.soap.SOAPBinding.Use;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		//String buff_sess1/Player-team
		Scanner sc = new Scanner(System.in);
		
		String player;
		String team;
		
		System.out.println("Enter the player name");
		player = sc.nextLine();
		System.out.println("Enter the team name");
		team = sc.nextLine();
		UserMainCode.display(player, team);
		sc.close();
		*/
		
		
		/*	
 		//String buff_sess1/ String Builder
		
		Scanner sc = new Scanner(System.in);
		
		String fname;
		String lname;
		
		fname = sc.nextLine();
		lname = sc.nextLine();
		
		UserMainCode.display(fname, lname);
		
		sc.close();
		*/
		
		/*
		//String buff_sess1/ String tokenizer 2
		
		Scanner sc = new Scanner(System.in);
		
		String teamNames;
		
		//Input
		System.out.println("Enter the team names");
		teamNames = sc.nextLine();

		
		UserMainCode.display(teamNames);
		
		sc.close();
		*/
		
		
		//String buff_sess1/ String tokenizer 4
		
		Scanner sc = new Scanner(System.in);
		
		String playerDetails;
		
		//Input
		System.out.println("Enter the player details");
		playerDetails = sc.nextLine();

		
		UserMainCode.display(playerDetails);
		
		sc.close();
	}

}
