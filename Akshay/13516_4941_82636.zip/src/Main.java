import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		//Fundamentals Session1/Dhoni Marriage 
		Scanner sc = new Scanner(System.in);
		int Date = Integer.parseInt(sc.nextLine());
		
		if(Date%4 == 0 && Date%100 != 0)
			System.out.println("Yes");
		else if(Date%100 == 0 && Date % 400 == 0)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		sc.close();
		*/
		
		
		//Fundamentals Session 1/Dhoni First meet
		Scanner sc = new Scanner(System.in);
		
		int seat = Integer.parseInt(sc.nextLine());
		
		if(seat%6 == 5 || seat%6 == 2)
			System.out.println("Yes");
		else
			System.out.println("No");
		
		sc.close();
		
	}

}
