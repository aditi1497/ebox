import java.util.Scanner;
public class Main {
	public static void main(String[] args) {		
		/*
		// TODO Auto-generated method stub
*/
/*		
 		//Day 14/Classes and object III/Sess 1 Player details
 		Scanner sc = new Scanner(System.in);
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P = new Player(name, country, skill);
		PlayerBO playerBO = new PlayerBO();
		
		//System.out.println(P.toString());
		playerBO.displayPlayerDetails(P);
		*/
		
		
		//Day14//Classes and Objects III/Sess 1 Delivery Details
		Scanner sc = new Scanner(System.in);
		
		int deliveries = 0;
		System.out.println("Enter the number of deliveries");
		deliveries = Integer.parseInt(sc.nextLine());
		
		Delivery[] deliveryList = new Delivery[deliveries];
		
		//Inputs
		for(int i = 0; i < deliveries; i++){
			
			Long over, ball;
			String batsman = new String();
			String bowler = new String();
			String nonStriker = new String();
			
			System.out.println("Enter the over");
			over = Long.parseLong(sc.nextLine());
			System.out.println("Enter the ball");
			ball = Long.parseLong(sc.nextLine());
			System.out.println("Enter the batsman");
			batsman = sc.nextLine();
			System.out.println("Enter the bowler");
			bowler = sc.nextLine();
			System.out.println("Enter the nonStriker");
			nonStriker = sc.nextLine();
			
			deliveryList[i] = new Delivery(over, ball, batsman, bowler, nonStriker);
		}
		
		//Outputs
		DeliveryBO dbo = new DeliveryBO();
		dbo.displayAllDeliveryDetails(deliveryList);
		
		}
}