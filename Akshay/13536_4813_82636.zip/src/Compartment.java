
public abstract class Compartment {
	public abstract void notice();

}
