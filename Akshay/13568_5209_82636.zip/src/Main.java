import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Exception session2/Custom Exception
		Scanner sc = new Scanner(System.in);
		int age;
		String name;
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the player age");
		
		try{
			age = Integer.parseInt(sc.nextLine());
			if(age < 19)
				throw new CustomException();
			else
				System.out.println("Player name : " + name + "\nPlayer age : " + age);
				
		}
		catch(CustomException ce){
			System.exit(0);
		}
		
		
	}

}
