import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
	/*	String teamData = sc.nextLine();
		boolean valid = true;
		
		try{
			Integer.parseInt(teamData.substring(0, 4));
			
		}
		catch(NumberFormatException nfe){
			valid = false;
		}
		
		if(teamData.substring(3).length() >= 23 || teamData.substring(3).length() < 4)
			valid = false;
		
		if(!Character.isDigit(teamData.charAt(teamData.length()-1)))
			valid = false;
		
		if(valid)
			System.out.println("Valid");
		else
			System.out.println("Invalid");*/
		
		System.out.println("Enter the player name");
		String name = sc.nextLine();
		System.out.println("Enter the team name");
		String teamName = sc.nextLine();
		
		StringBuilder concat = new StringBuilder();
		concat.append(name + "#" + teamName);
		System.out.println(concat);
		
		
		sc.close();
		
	}

}
