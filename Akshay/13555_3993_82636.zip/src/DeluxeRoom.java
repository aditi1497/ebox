
public class DeluxeRoom extends HotelRoom{
	
	protected Integer ratePerSqFeet;

	//Getter and Setter
	public void setRatePerSqFeet(Integer ratePerSqFeet) {
		this.ratePerSqFeet = ratePerSqFeet;
	}
	//Explicitly overriding getRatePerSqFeet
	@Override
	public Integer getRatePerSqFeet() {
		if(hasWifi)
			return ratePerSqFeet+2;
		else
			return ratePerSqFeet;
	
	}

	//Constructor(<super args >) Hardcode ratePerSqFeet as 10
	public DeluxeRoom(String hotelName, Integer numberOfSqFeet, boolean hasTV, boolean hasWifi) {
		super(hotelName, numberOfSqFeet, hasTV, hasWifi);
		this.ratePerSqFeet = 10;
	}
	//Empty Constructor
	public DeluxeRoom() {
	}
	/*
	@Override
	public Integer calculateTariff() {
		// TODO Auto-generated method stub
		return numberOfSqFeet*getRatePerSqFeet();
	}

	
	
	*/

}
