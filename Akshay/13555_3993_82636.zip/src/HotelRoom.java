
public class HotelRoom {
	protected String hotelName;
	protected Integer numberOfSqFeet;
	protected boolean hasTV;
	protected boolean hasWifi;
	
	//Getters and Setters
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public Integer getNumberOfSqFeet() {
		return numberOfSqFeet;
	}
	public void setNumberOfSqFeet(Integer numberOfSqFeet) {
		this.numberOfSqFeet = numberOfSqFeet;
	}
	public boolean isHasTV() {
		return hasTV;
	}
	public void setHasTV(boolean hasTV) {
		this.hasTV = hasTV;
	}
	public boolean isHasWifi() {
		return hasWifi;
	}
	public void setHasWifi(boolean hasWifi) {
		this.hasWifi = hasWifi;
	}
	
	//Constructor (String, Integer, Boolean X2)
	public HotelRoom(String hotelName, Integer numberOfSqFeet, boolean hasTV, boolean hasWifi) {
		super();
		this.hotelName = hotelName;
		this.numberOfSqFeet = numberOfSqFeet;
		this.hasTV = hasTV;
		this.hasWifi = hasWifi;
	}
	
	//Empty Constructor
	public HotelRoom() {
		super();
	}
	//Tariff calculation
	public Integer calculateTariff(){
		
		return numberOfSqFeet*getRatePerSqFeet();
	}
	
	//Getting rate of a square foot
	public Integer getRatePerSqFeet(){
		return 0;
	}

}
