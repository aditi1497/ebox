
public class OverRangeException extends Exception{

	public OverRangeException(){
		System.out.println("OverRangeException: Over is not in the specified range");
	}
}
