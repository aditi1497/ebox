import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Exception handling 1
		Scanner sc = new Scanner(System.in);
		
		long runs;
		int overs;
		float crr;
		

		
		try{
			System.out.println("Enter the total runs scored");
			runs = Long.parseLong(sc.nextLine());
			System.out.println("Enter the total overs faced");
			overs = Integer.parseInt(sc.nextLine());
			crr = (float)runs/overs;
			if(overs == 0)
				throw new ArithmeticException();
			else
				System.out.println("Current Run Rate : " + String.format("%.2f", crr));
		}
		catch (Exception e){
			if(e instanceof ArithmeticException || e instanceof NumberFormatException)
				System.out.println(e.toString().split(":")[0]);
			else
				System.out.println("Error!!");
		}
		
		
	}

}
