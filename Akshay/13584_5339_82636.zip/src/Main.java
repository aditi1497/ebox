import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		//Collections/Sets/Session1/HashSet1
		
		Scanner sc = new Scanner(System.in);
		
		int players = Integer.parseInt(sc.nextLine());
		
		TreeSet<String> playerList = new TreeSet<String>();
		
		for(int i = 0; i < players; i++){
			playerList.add(sc.nextLine());
		}
	
		System.out.println(playerList.size());
		
		sc.close();
		*/
		
		
/*
		//Collections/Sets/Player of the Match
		
		Scanner sc = new Scanner(System.in);
		
		int players = Integer.parseInt(sc.nextLine());
		
		TreeSet<String> playerList = new TreeSet<String>();
		
		for(int i = 0; i < players; i++)
			playerList.add(sc.nextLine());
	
		Iterator it = playerList.iterator();
		
		while(it.hasNext())
			System.out.println(it.next());
		
		
		sc.close();
		*/
		
		
		
		//Collections/Sets/Set - Revenue Manager
		
				Scanner sc = new Scanner(System.in);
				
				TreeSet<Revenue> revenueList = new TreeSet<Revenue>();
				
				while(true){
					
					String category;
					String revenue;
					
					System.out.println("Enter revenue category");
					category = sc.nextLine();
					System.out.println("Enter revenue amount");
					revenue = sc.nextLine();
					
					revenueList.add(new Revenue (category, revenue));
					
					String choice;
					System.out.println("Do you want to continue(yes/no):");
					choice = sc.nextLine();
					
					if(choice.equals("yes"))
						continue;
					else
						break;
				}
				
				System.out.println("Top spending categories");
			
				Iterator<Revenue> it = revenueList.descendingIterator();
				
				long total = 0;
				
				Revenue temp;
				
				System.out.println(String.format("%-15s%-15s", "Category", "Amount"));
				
				while(it.hasNext()){
					
					temp = it.next();
					System.out.println(temp);
					total = total + Long.parseLong(temp.getAmount());
					
				}
					
				System.out.println("Total amount earned: " + total);
				
				sc.close();
		
	}
	

}
