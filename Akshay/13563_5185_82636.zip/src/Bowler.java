
public class Bowler extends CricketPlayer implements IPlayerStatistics{

	private Integer noOfWickets;

	//Getter and Setter
	public Integer getNoOfWickets() {
		return noOfWickets;
	}

	public void setNoOfWickets(Integer noOfWickets) {
		this.noOfWickets = noOfWickets;
	}

	//Constructor (<super args>, Integer)
	public Bowler(Integer noOfWickets){
		super();
		this.noOfWickets = noOfWickets;
	}

	@Override
	public void displayPlayerStatistics() {
		// TODO Auto-generated method stub
		
	}
	
	
}
