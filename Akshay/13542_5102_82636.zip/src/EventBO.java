import java.util.StringTokenizer;

class EventBO {
	
	public Event createEvent(String data, Innings[] InningList)
	{

		//fill your code;
		StringTokenizer eventDetails = new StringTokenizer(data, ",");
			
			long eventNumber = Long.parseLong(eventDetails.nextToken());
			String raider = eventDetails.nextToken();;
			long teamOneScore = Long.parseLong(eventDetails.nextToken());
			long teamTwoScore = Long.parseLong(eventDetails.nextToken());
			long inningsNumber = Long.parseLong(eventDetails.nextToken());
			Innings i = null;
			
			for(Innings i1 :InningList){
				if(i1.getInningsNumber() == inningsNumber)
					i = i1;			
			
			}
		
		return new Event(eventNumber, raider, teamOneScore, teamTwoScore, i);
		
	}
	
	

	public  Long findInningsNumber(Event[] eventList, long eventNumber) {
		
		//fill your code;
		for(Event e :eventList){
			if(e.getEventNumber() == eventNumber)
				return e.getInnings().getInningsNumber();
		}
		
		return null;
		
	}

}
