import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		int num = Integer.parseInt(sc.nextLine());
		
		ArrayList<Integer> runsList = new ArrayList<Integer>();
		
		for(int i = 0; i < num; i++)
			runsList.add(Integer.parseInt(sc.nextLine()));
		
		int sum = 0;
		
		for(int r :runsList)
			sum += r;
		
		double avg = (double)sum/runsList.size();
		System.out.println(sum);
		System.out.println(String.format("%.2f", avg));
		sc.close();
		

	}

}
