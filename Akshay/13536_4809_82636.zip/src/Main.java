import java.util.Scanner;
public class Main {
	public static void main(String[] args) {		
		/*
		// TODO Auto-generated method stub
*/
		Scanner sc = new Scanner(System.in);
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P = new Player(name, country, skill);
		PlayerBO playerBO = new PlayerBO();
		
		//System.out.println(P.toString());
		playerBO.displayPlayerDetails(P);}
}