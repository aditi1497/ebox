import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		//Strings/Session1/CharAt
		
		Scanner sc = new Scanner(System.in);
		
		char character1 = 0;
		String team1 = new String();
		String team2 = new String();
		System.out.println("Enter team1");
		team1 = sc.nextLine();
		System.out.println("Enter team2");
		team2 = sc.nextLine();
		System.out.println("Enter third character");
		character1 = sc.nextLine().charAt(0);
		
		if(team1.charAt(2) == character1)
			System.out.println("Winner Team : " + team1);
		else if(team2.charAt(2) == character1)
			System.out.println("Winner Team : " + team2);
			*/
		
		
		/*
		//Strings /Sess1/EqualsIgnoreCase
		
		Scanner sc = new Scanner(System.in);
		
		String venue1 = new String();
		String venue2 = new String();
		
		System.out.println("Enter venue1");
		venue1 = sc.nextLine();
		System.out.println("Enter venue2");
		venue2 = sc.nextLine();
		
		
		if(venue1.equalsIgnoreCase(venue2))
			System.out.println("Both the venues are the same.");
		else
			System.out.println("Both the venues are different.");
			
			*/
		
		/*
		//Strings / Session1/ IndexOf, LastIndexOf
		
		Scanner sc = new Scanner(System.in);
		
		int numberOfPlayers;
		System.out.println("Enter the number of players");
		numberOfPlayers = Integer.parseInt(sc.nextLine());
		
		String [] playerList = new String[numberOfPlayers];
		
		for(int i = 0; i < numberOfPlayers; i++){
			playerList[i] = sc.nextLine();
		}
		
		System.out.println("Player of the Match:");
		for(String str: playerList){
			if(str.indexOf('a') == str.lastIndexOf('a'))
				System.out.println(str);
				
			}
			
		*/
		
		
		
		//Strings/Sess1/SubSequence
		
		Scanner sc = new Scanner(System.in);
		
		String teamName = new String();
		
		System.out.println("Enter team name");
		teamName = sc.nextLine();
		
		int stInd, endInd;
		
		System.out.println("Enter starting index of the sequence");
		stInd = Integer.parseInt(sc.nextLine());
		System.out.println("Enter ending index of the sequence");
		endInd = Integer.parseInt(sc.nextLine());
		
		System.out.println(teamName.substring(stInd, endInd));
		
		
	}

}
