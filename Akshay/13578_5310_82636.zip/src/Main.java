import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import org.w3c.dom.UserDataHandler;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		//Collections 1/List1
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> l = new ArrayList<Integer>();
		
		int length;
		length = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < length; i++){
			
			int i1 = Integer.parseInt(sc.nextLine());
			l.add(i1);
		}
		
		float sum = 0;
		for(Object o:l)
			sum += (int)o;
		
		System.out.println((int)sum);
		System.out.println(String.format("%.1f", sum/length));
		
		sc.close();
		*/
		
		
		/*
		//Collections 1/List2
				Scanner sc = new Scanner(System.in);
				
				ArrayList<Integer> l = new ArrayList<Integer>();
				
				int length;
				length = Integer.parseInt(sc.nextLine());
				
				for(int i = 0; i < length; i++){
					
					int i1 = Integer.parseInt(sc.nextLine());
					l.add(i1);
				}
				
				Collections.sort(l);
				
				for(int i:l){
					System.out.println(i);
				}

				
				sc.close();
		*/
		
		/*
		//Collections 1/List3
		Scanner sc = new Scanner(System.in);
		
		ArrayList<String> l = new ArrayList<String>();
		
		int length;
		length = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < length; i++){
			
			String str = sc.nextLine();
			l.add(str);
		}		
		
		String venue = sc.nextLine();
		int count = 0;
		
		for(String s: l){
			
			if(s.equals(venue))
				count++;
		}	
		
		System.out.println(count);
		
		sc.close();
		*/
		
		
		/*
		//Collections 1/List4
		Scanner sc = new Scanner(System.in);
				
		System.out.println("Enter the team name");
		String team = sc.nextLine();
		
		ArrayList<Integer> runs = new ArrayList<Integer>();
		
		int n;
		System.out.println("Enter the number of matches played in home ground");
		n = Integer.parseInt(sc.nextLine());
		
		//Home ground runs
		System.out.println("Enter the runs scored");
		for(int i = 0; i < n; i++){
			runs.add(Integer.parseInt(sc.nextLine()));
		}
		
		int m;
		System.out.println("Enter the number of matches played in other ground");
		m = Integer.parseInt(sc.nextLine());
		
		//Away runs
		System.out.println("Enter the runs scored");
		for(int i = 0; i < m; i++){
			runs.add(Integer.parseInt(sc.nextLine()));
		}
		
		//Display runs
		System.out.println("Runs scored by " + team);
		for(int i :runs)
			System.out.println(i);
		
		//>300
		System.out.println("Run scored by " + team + " more than 300");
		for(int i :runs){
			if(i>300)
				System.out.println(i);
		}
		
		sc.close();
		*/
		
		
		//Collections 1/List5
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList<String> IPLs8 = new ArrayList<String>();
		
		System.out.println("Enter the top 5 scorers of IPL Season 8");
		for(int i = 0; i < 5; i++){
			IPLs8.add(sc.nextLine());
			
		}
		ArrayList<String> IPLs9 = new ArrayList<String>();
		
		System.out.println("Enter the top 5 scorers of IPL Season 9");
		for(int i = 0; i < 5; i++){
			IPLs9.add(sc.nextLine());
			
		}
		
		System.out.println("Consistent run scorers");
		IPLs8.retainAll(IPLs9);
		
		for(String str:IPLs8)
			System.out.println(str);
		
		sc.close();
		
	}

}
