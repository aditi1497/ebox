import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
	// TODO Auto-generated method stub
		
		
		
/*		
		//====================learn to code Classes and objects I /Sess 1, player
		Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		Player P = new Player();
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		P.setName(name);
		System.out.println("Enter the country name");
		country = sc.nextLine();
		P.setCountry(country);
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		P.setSkill(skill);
		System.out.println("Player Details :");
		System.out.println("Player Name : " + P.getName());
		System.out.println("Country Name : " + P.getCountry());
		System.out.println("Skill : " + P.getSkill());
		
	*/	
		
		
		
/*		
		//====================learn to code Classes and objects I /Sess 1, venue
		Scanner sc = new Scanner(System.in);
		
		String vname = new String();
		String vcity = new String();
		
		System.out.println("Enter the venue name");
		vname = sc.nextLine();
		System.out.println("Enter the city name");
		vcity = sc.nextLine();
		
		Venue v = new Venue();
		v.setCity(vcity);
		v.setName(vname);
		
		System.out.println("Venue Details :");
		System.out.println("Venue Name : " + vname);
		System.out.println("City Name : " + vcity);
		
	*/	
		
		
		
		
/*		 //====================learn to code Classes and objects II /Sess 1, venue
		int venues;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of venues");
		venues = sc.nextInt();
		sc.nextLine();
		
		Venue[] ven = new Venue[venues];
		
		String venueDetails = new String();
		
		
		for(int i = 0; i < venues; i++){
			
			System.out.println("Enter the details of venue " + (i+1));
			venueDetails = sc.nextLine();
			String [] details = venueDetails.split(",");
			
			//System.out.println(details[0]+" "+details[1]);
			ven[i] = new Venue(details[0], details[1]);
			}

		//Displaying details
		System.out.println("Venue Details");
		
		for(int i = 0; i < venues; i++){
			ven[i].display();
		}
		
	*/	
		
		
		
/*		
		//====================learn to code Classes and objects II /Sess II, Innings
 		Scanner sc = new Scanner(System.in);
		
		int innings;
		System.out.println("Enter the number of innings");
		innings = Integer.parseInt(sc.nextLine());
		
		Innings []inn = new Innings[innings];
		
		for(int i = 0; i < innings; i ++){
			
			System.out.println("Enter the values for Innings " + (i +1));
			String bt;
			Long run;
			System.out.println("Enter the BattingTeam");
			bt = sc.nextLine();
			System.out.println("Enter the runs scored");
			run = Long.parseLong(sc.nextLine());
			
			inn[i] = new Innings(bt, run);
			
		}
		
		System.out.println("Innings Details");
		for(int i = 0; i < innings; i ++){
			System.out.println("Innings " + (i+1));
			System.out.println(inn[i].toString());
		}
		
	*/	
		
/*	
		//====================learn to code Classes and objects II /Sess 2, Player
		 Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player 1 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P1 = new Player(name, country, skill);
		System.out.println(P1.toString());
		
		System.out.println("Enter the player 2 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P2 = new Player(name, country, skill);
		System.out.println(P2.toString());
		
		if(P1.equals(P2))
			System.out.println("Both the player details are same.");
		else
			System.out.println("Both the player details are not same.");

	*/
		
/*		//Code challenge Classes and objects I
		
		Scanner sc = new Scanner(System.in);
		
		String teamDetails = new String();
		System.out.println("Enter the team details");
		teamDetails = sc.nextLine();
		
		String [] splitDetails = teamDetails.split("#");
		Team India = new Team();
		
		India.setName(splitDetails[0]);
		India.setCoach(splitDetails[1]);
		India.setHome(splitDetails[2]);
		India.setCaptain(splitDetails[3]);
		India.setPlayers(splitDetails[4]);
		System.out.println("Team Detail");
		System.out.println("Team : " + India.getName());
		System.out.println("Coach : " + India.getCoach());
		System.out.println("Home : " + India.getHome());
		System.out.println("Players : " + India.getPlayers());
		System.out.println("Captain : " + India.getCaptain());
			*/
		
		//Classes and Objects IB/ Sess 2
		
		/*Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String coach = new String();
		String location = new String();
		String players = new String();
		String captain = new String();
		
		//Classes and Objects 1B/ Sess 2
		 System.out.println("Enter the team name");
		 name = sc.nextLine();
		 System.out.println("Enter the coach name");
		 coach = sc.nextLine();
		 System.out.println("Enter the location name");
		 location = sc.nextLine();
		 System.out.println("Enter the players name");
		 players = sc.nextLine();
		 System.out.println("Enter the captain name");
		 captain = sc.nextLine();
		 
		 
		 Team India = new Team();
		 
		 India.setCaptain(captain);
		 India.setName(name);
		 India.setCoach(coach);
		 India.setPlayers(players);
		 India.setLocation(location);
		 
		 India.displayTeamDetails();
		 */
		
		Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P = new Player(name, country, skill);
		System.out.println(P.toString());
		
		System.out.println("Verify and Update Player Details");

		
		while(true){
			
			int ch;
			System.out.println("Menu");
			System.out.println("1.Update Player Name");
			System.out.println("2.Update Country Name");
			System.out.println("3.Update Skill");
			System.out.println("4.All informations Correct/Exit");
			System.out.println("Type 1 or 2 or 3 or 4");
			ch = Integer.parseInt(sc.nextLine());
			

			
			if(ch == 1){ 
				System.out.println("The current player name is " + P.getName());
				System.out.println("Enter the player name");
				name = sc.nextLine();
				P.setName(name);}
			else if(ch ==2){ 
				System.out.println("The current country name is " + P.getCountry());
				System.out.println("Enter the country name");
				country = sc.nextLine();
				P.setCountry(country);}
			else if (ch == 3){ 
				System.out.println("The current skill is " + P.getSkill());
				System.out.println("Enter the skill");
				skill = sc.nextLine();
				P.setSkill(skill);}
			else{				
				System.out.println(P.toString());
				break;}

		}
		
		
		 
			 
		}
		
		
	}

