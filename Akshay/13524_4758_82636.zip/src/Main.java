import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		
		
		
		/*====================learn to code Classes and objects I /Sess 1, player
		Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		Player P = new Player();
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		P.setName(name);
		System.out.println("Enter the country name");
		country = sc.nextLine();
		P.setCountry(country);
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		P.setSkill(skill);
		System.out.println("Player Details :");
		System.out.println("Player Name : " + P.getName());
		System.out.println("Country Name : " + P.getCountry());
		System.out.println("Skill : " + P.getSkill());
		*/
		
		
		
		
		
		/*====================learn to code Classes and objects I /Sess 1, venue
		Scanner sc = new Scanner(System.in);
		
		String vname = new String();
		String vcity = new String();
		
		System.out.println("Enter the venue name");
		vname = sc.nextLine();
		System.out.println("Enter the city name");
		vcity = sc.nextLine();
		
		Venue v = new Venue();
		v.setCity(vcity);
		v.setName(vname);
		
		System.out.println("Venue Details :");
		System.out.println("Venue Name : " + vname);
		System.out.println("City Name : " + vcity);
		*/
		
		
		
		
		
		/* ====================learn to code Classes and objects II /Sess 1, venue
		int venues;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of venues");
		venues = sc.nextInt();
		sc.nextLine();
		
		Venue[] ven = new Venue[venues];
		
		String venueDetails = new String();
		
		
		for(int i = 0; i < venues; i++){
			
			System.out.println("Enter the details of venue " + (i+1));
			venueDetails = sc.nextLine();
			String [] details = venueDetails.split(",");
			
			//System.out.println(details[0]+" "+details[1]);
			ven[i] = new Venue(details[0], details[1]);
			}

		//Displaying details
		System.out.println("Venue Details");
		
		for(int i = 0; i < venues; i++){
			ven[i].display();
		}
		*/
		
		
		
		
		
		/*====================learn to code Classes and objects II /Sess II, Innings
 		Scanner sc = new Scanner(System.in);
		
		int innings;
		System.out.println("Enter the number of innings");
		innings = Integer.parseInt(sc.nextLine());
		
		Innings []inn = new Innings[innings];
		
		for(int i = 0; i < innings; i ++){
			
			System.out.println("Enter the values for Innings " + (i +1));
			String bt;
			Long run;
			System.out.println("Enter the BattingTeam");
			bt = sc.nextLine();
			System.out.println("Enter the runs scored");
			run = Long.parseLong(sc.nextLine());
			
			inn[i] = new Innings(bt, run);
			
		}
		
		System.out.println("Innings Details");
		for(int i = 0; i < innings; i ++){
			System.out.println("Innings " + (i+1));
			System.out.println(inn[i].toString());
		}*/
		
		
		
		
		/*====================learn to code Classes and objects II /Sess 1, Player
		 Scanner sc = new Scanner(System.in);
		
		String name = new String();
		String country = new String();
		String skill = new String();
		
		System.out.println("Enter the player 1 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P1 = new Player(name, country, skill);
		System.out.println(P1.toString());
		
		System.out.println("Enter player 2 details");
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the country name");
		country = sc.nextLine();
		System.out.println("Enter the skill");
		skill = sc.nextLine();
		
		Player P2 = new Player(name, country, skill);
		System.out.println(P2.toString());
		
		if(P1.equals(P2))
			System.out.println("Both the player details are the same.");
		else
			System.out.println("Both the player details are not the same.");*/

		
		
	}

}
