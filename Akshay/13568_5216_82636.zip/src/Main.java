import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 
		//Exception session2/Custom Exception
		Scanner sc = new Scanner(System.in);
		int age;
		String name;
		
		System.out.println("Enter the player name");
		name = sc.nextLine();
		System.out.println("Enter the player age");
		
		try{
			age = Integer.parseInt(sc.nextLine());
			if(age < 19)
				throw new CustomException();
			else
				System.out.println("Player name : " + name + "\nPlayer age : " + age);
				
		}
		catch(CustomException ce){
			System.exit(0);
		}
		*/
		
		
		//Eception session2/TeamNameNotFound
		Scanner sc = new Scanner(System.in);
		
		String []teamList = {"Chennai Super Kings", "Royal Challengers Bangalore", "Rajasthan Royals", "Deccan Chargers", "	Kings XI Punjab", "Kolkata Knight Riders", "Mumbai Indians", "Delhi Daredevils"};
		
		
		boolean flag = false;
		try{
			
			System.out.println("Enter the expected winner team of IPL Season 4");
			String winnerTeam = sc.nextLine();
			
			for(String str: teamList){
				if(winnerTeam.equals(str)){
					flag = true;
					break;
				}
			}
			
			if (!flag)
				throw new TeamNameNotFound();
			
			flag = false;
			
			System.out.println("Enter the expected runner Team of IPL Season 4");
			String runnerUp = sc.nextLine();
			
			for(String str: teamList){
				if(runnerUp.equals(str)){
					flag = true;
					break;
				}
			}
			
			if (flag == false)
				throw new TeamNameNotFound();
			
			System.out.println("Expected IPL Season 4 winner: " + winnerTeam);
			System.out.println("Expected IPL Season 4 runner: " + runnerUp);
		}
		
		catch(Exception e){}
		
		sc.close();
		
		
	}
		

}
