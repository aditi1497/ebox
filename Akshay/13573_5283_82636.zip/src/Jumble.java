import java.util.StringTokenizer;

public class Jumble {

	
	//Display summaries 1
	public static void displaySummary(String details){
		
		StringTokenizer st = new StringTokenizer(details, " ");
		String [] detailList = details.split(" ");
		//StringBuffer detailList = new StringBuffer();
		
		while(st.hasMoreTokens()){
			System.out.println(st.nextToken());
		}
		for(int i = (detailList.length - 1); i >= 0; i--){
			System.out.print(detailList[i] + " ");
		}
	}
	
	//Display summaries 2
	public static void displayOutcome(String outcome){
		
		StringTokenizer st = new StringTokenizer(outcome, "!");
		
		while(st.hasMoreTokens()){
			System.out.print(st.nextToken());
		}
	}
	
}
