
public class UserMainCode {

	public static boolean validateTeam(String team){
		
		String teamName = team.toLowerCase();
		int length = teamName.length();
		int ve = 0, vo = 0;
		
		for(int i = 0; i < length; i++){
			if(teamName.charAt(i) == 'a'|| teamName.charAt(i) == 'e' || teamName.charAt(i) == 'i' || teamName.charAt(i) == 'o' || teamName.charAt(i) == 'u'){
			
				if((i+1) %2 == 0)
					ve++;
				else
					vo++;
			
			}
			
			
		}
		if(ve>vo)
			return true;
		else
			return false;
	
	}
}