
public class PaybackCard {
    
    private Integer pointsEarned;
    private Double totalAmount;

    
    
    
    
}
