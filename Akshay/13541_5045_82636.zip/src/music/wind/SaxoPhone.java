package music.wind;

import music.playable.Playable;


public class SaxoPhone implements Playable{
	public void Play(){
		System.out.println("===Playing the Sax===");
	}

}
