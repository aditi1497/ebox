package music.string;

import music.playable.Playable;

public class Veena implements Playable{
	public void Play(){
		System.out.println("~~~Playing the veena~~~");
	}

}
