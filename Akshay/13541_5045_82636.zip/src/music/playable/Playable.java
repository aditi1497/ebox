package music.playable;

public interface Playable {

	public abstract void Play();
}
