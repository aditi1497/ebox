import java.util.*;


public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
	
		
  	System.out.println("Enter the number of matches");
  	
		String str=s.nextLine();
		int n=Integer.parseInt(str);
		Outcome []o=new Outcome[n];
		
		for(int i=0;i<o.length;i++)
		{
			System.out.println("Enter match "+(i+1)+" details");
			//String str1=s.nextLine();
			
			
//			Long l1=Long.parseLong(str2[0]);
//			Long l2=Long.parseLong(str2[1]);
			System.out.println("Enter the date");
			String str2=s.nextLine();
			System.out.println("Enter the status");
			String str3=s.nextLine();
			
			System.out.println("Enter the winner team");
			String str4=s.nextLine();
			
			System.out.println("Enter the player of match");
			String str5=s.nextLine();
			
			
			
			o[i]=new Outcome(str3,str4,str5,str2);
			
		}
		
		OutcomeBO ob =new OutcomeBO();
		ob.displayAllOutcomeDetails(o);
		System.out.println("Enter the date to be searhed");
		String st=s.nextLine();
	//	OutcomeBO ob1 =new OutcomeBO();
		ob.displaySpecificOutcomeDetails(o,st);
		
		//System.out.println(o[0].getDate());
		
		
		
	}}
